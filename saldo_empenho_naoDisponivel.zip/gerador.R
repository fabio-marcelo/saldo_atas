# ===========================================================================
# CONFIGURAÇÃO DE AMBIENTE E PACOTES (TOTALMENTE AUTOSSUFICIENTE)
# ===========================================================================
cat("Verificando e instalando pacotes necessarios. Por favor, aguarde...\n")

options(repos = c(CRAN = "https://cloud.r-project.org/"))

# --- Configuração de Ambiente para evitar erros de permissão ---
meu_diretorio_de_pacotes <- file.path(Sys.getenv("USERPROFILE"), "R_packages")
if (!dir.exists(meu_diretorio_de_pacotes)) dir.create(meu_diretorio_de_pacotes)

# Garante que o R use essa pasta para salvar os pacotes
.libPaths(c(meu_diretorio_de_pacotes, .libPaths()))

requiredPackages <- c("dplyr", "tidyr", "knitr", "readr", "stringr", 
                      "janitor", "tinytex", "kableExtra")   

# Função silenciosa para verificar e instalar pacotes
for(p in requiredPackages){
  if(!require(p, character.only = TRUE, quietly = TRUE)) {
    cat(paste("Instalando pacote:", p, "\n"))
    install.packages(p, dependencies = TRUE, repos = "https://cloud.r-project.org/")
    library(p, character.only = TRUE, quietly = TRUE)
  }
}

# ===========================================================================
# VERIFICAÇÃO INTELIGENTE DO LATEX
# ===========================================================================
tem_latex <- nzchar(Sys.which("pdflatex"))
tem_tinytex <- tinytex::is_tinytex()

if (tem_latex || tem_tinytex) {
  cat("Motor de PDF (LaTeX/MiKTeX) detectado no sistema! Pronto para gerar PDFs diretos.\n")
} else {
  cat("\n==================================================================\n")
  cat("ATENCAO: O motor de PDF nao foi encontrado neste computador.\n")
  cat("Baixando e instalando o TinyTeX. Isso pode demorar alguns minutos...\n")
  cat("==================================================================\n\n")
  
  install.packages("tinytex", repos = "https://cloud.r-project.org/")
  
  tryCatch({
    tinytex::install_tinytex(force = TRUE)
  }, error = function(e) {
    cat("\nAviso: Ocorreu um erro no servidor do TinyTeX (", e$message, ").\n")
  })
}



# Função robusta de escape de caracteres LaTeX
escape_latex <- function(x) {
  if (length(x) == 0) return("")
  x <- as.character(x)
  x[is.na(x)] <- ""
  x <- gsub("\\\\", "\\\\textbackslash ", x)
  x <- gsub("&", "\\\\&", x)
  x <- gsub("%", "\\\\%", x)
  x <- gsub("\\$", "\\\\$", x)
  x <- gsub("#", "\\\\#", x)
  x <- gsub("_", "\\\\_", x)
  x <- gsub("\\{", "\\\\{", x)
  x <- gsub("\\}", "\\\\}", x)
  x <- gsub("~", "\\\\textasciitilde ", x)
  x <- gsub("\\^", "\\\\textasciicircum ", x)
  return(x)
}

# ===========================================================================
# PASSO 1: SELEÇÃO DO ARQUIVO CSV
# ===========================================================================
arquivo_entrada <- tryCatch({
  if (.Platform$OS.type == "windows") {
    res <- utils::choose.files(caption = "Selecione a planilha CSV do Empenho", multi = FALSE)
    if (length(res) == 0) stop("Cancelado")
    res
  } else {
    file.choose()
  }
}, error = function(e) {
  cat("\nSelecao cancelada. Encerrando.\n")
  Sys.sleep(2)
  quit(save = "no")
})

cat("Arquivo selecionado:", arquivo_entrada, "\n\n")

# ===========================================================================
# PASSO 2: LEITURA E DETECÇÃO DE CABEÇALHO
# ===========================================================================
dados_brutos_raw <- read.csv(
  arquivo_entrada,
  sep = ";",
  header = FALSE,
  stringsAsFactors = FALSE,
  encoding = "latin1",
  check.names = FALSE,
  fill = TRUE
)

detectar_cabecalho <- function(df, colunas_esperadas, minimo_match = 3){
  resultados <- sapply(seq_len(nrow(df)), function(i){
    linha <- tolower(trimws(as.character(unlist(df[i, ]))))
    sum(tolower(colunas_esperadas) %in% linha, na.rm = TRUE)
  })
  
  melhor_linha <- which.max(resultados)
  maior_match <- resultados[melhor_linha]
  
  if(maior_match < minimo_match){
    stop("Não foi possível identificar o cabeçalho no arquivo CSV.")
  }
  return(melhor_linha)
}

colunas_referencia <- c(
  "Solicitante(s)",
  "Quantidade total LFDA-RS",
  "Saldo atualizado",
  "sei",
  "Item",
  "Descrição conforme Termo de Referência (anexo do edital da licitação)",
  "Porcentagem adquirida do item"
)

linha_cabecalho <- detectar_cabecalho(dados_brutos_raw, colunas_referencia)

cabecalho_real <- as.character(dados_brutos_raw[linha_cabecalho, ])
cabecalho_limpo <- cabecalho_real %>%
  gsub("[\r\n]", " ", .) %>%
  gsub("\\s+", " ", .) %>%
  trimws()

vazios <- is.na(cabecalho_limpo) | cabecalho_limpo == ""
cabecalho_limpo[vazios] <- paste0("COL_", which(vazios))

manter_colunas <- !(
  grepl("^COL_", cabecalho_limpo) &
    sapply(seq_along(cabecalho_limpo), function(i){
      all(is.na(dados_brutos_raw[-seq_len(linha_cabecalho), i]))
    })
)

dados_brutos_raw <- dados_brutos_raw[, manter_colunas]
cabecalho_limpo <- cabecalho_limpo[manter_colunas]
cabecalho_limpo <- make.unique(cabecalho_limpo)
colnames(dados_brutos_raw) <- cabecalho_limpo

dados_brutos <- dados_brutos_raw[(linha_cabecalho + 1):nrow(dados_brutos_raw), ]
dados_brutos <- dados_brutos[
  rowSums(is.na(dados_brutos) | dados_brutos == "") < ncol(dados_brutos),
]
dados_brutos <- dados_brutos[, !grepl("^NA(\\.\\d+)?$", colnames(dados_brutos))]

cat("Tabela carregada:", nrow(dados_brutos), "linhas\n")

# ===========================================================================
# PASSO 3: PADRONIZAÇÃO E PREPARAÇÃO DOS DADOS
# ===========================================================================
dados_filtrados <- dados_brutos %>%
  mutate(
    Pregão = trimws(gsub("\\s+", " ", Pregão)),
    `Nº Ata` = trimws(gsub("\\s+", " ", `Nº Ata`))
  )

pasta_saida <- "Relatorios_PDF"
if(!dir.exists(pasta_saida)) dir.create(pasta_saida)

grupos <- dados_filtrados %>%
  filter(trimws(Pregão) != "" & !is.na(Pregão)) %>%
  distinct(Pregão) %>%
  pull(Pregão)

cat("\nTotal de pregões identificados:", length(grupos), "\n")

# ===========================================================================
# FUNÇÃO DE GERAÇÃO DO RELATÓRIO
# ===========================================================================
gerar_relatorio <- function(dados_grupo, pregao_atual, arquivo_pdf_final, titulo) {
  
  # Cálculo seguro da média (trata vírgula e valores em branco sem gerar aviso)
  valores_pct <- dados_grupo$`Porcentagem adquirida do item` %>%
    as.character() %>%
    gsub("%", "", .) %>%
    gsub(",", ".", .) %>%
    trimws()
  
  valores_num <- suppressWarnings(as.numeric(valores_pct))
  valores_validos <- valores_num[!is.na(valores_num)]
  
  media_str <- if(length(valores_validos) > 0) {
    paste0(sprintf("%.2f", mean(valores_validos)), "\\%")
  } else {
    "N/A"
  }
  
  # Seleção e sanitização dos campos
  itens <- dados_grupo %>%
    dplyr::select(
      Item,
      Solicitante = `Solicitante(s)`,
      `Saldo atualizado` = `Saldo atualizado`,
      `Quantidade total LFDA-RS` = `Quantidade total LFDA-RS`,
      `Nº Ata` = `Nº Ata`,
      `Descrição conforme TR` = `Descrição conforme Termo de Referência (anexo do edital da licitação)`,
      `Proposta (protocolo SEI)` = `Proposta (protocolo SEI)`,
      `Porcentagem adquirida` = `Porcentagem adquirida do item`
    ) %>%
    mutate(
      across(everything(), ~escape_latex(gsub("[\r\n]", " ", as.character(.))))
    )
  
  # Sanitiza também os nomes das colunas (remove o 'º' problemático para o LaTeX)
  colnames(itens) <- gsub("º", ".o", colnames(itens))
  colnames(itens) <- escape_latex(colnames(itens))
  
  # Tabela LaTeX
  tabela <- kable(
    itens,
    format = "latex",
    booktabs = TRUE,
    longtable = TRUE,
    escape = FALSE,
    align = c("c", "c", "c", "c", "c", "l", "c", "c")
  ) %>%
    kable_styling(
      latex_options = c("striped", "repeat_header"),
      font_size = 7
    ) %>%
    column_spec(1, width = "0.9cm") %>%
    column_spec(2, width = "1.8cm") %>%
    column_spec(3, width = "1.8cm") %>%
    column_spec(4, width = "2.0cm") %>%
    column_spec(5, width = "1.6cm") %>%
    column_spec(6, width = "10.0cm") %>%
    column_spec(7, width = "2.8cm") %>%
    column_spec(8, width = "2.8cm")
  
  tex_content <- c(
    "\\documentclass[10pt]{article}",
    "\\usepackage[landscape, left=0.7cm, right=0.7cm, top=1cm, bottom=1cm]{geometry}",
    "\\usepackage{booktabs}",
    "\\usepackage{longtable}",
    "\\usepackage{array}",
    "\\usepackage[table]{xcolor}",
    "\\usepackage[utf8]{inputenc}",
    "\\usepackage[T1]{fontenc}",
    "\\usepackage{helvet}",
    "\\renewcommand{\\familydefault}{\\sfdefault}",
    "\\setlength{\\tabcolsep}{3pt}",
    "\\renewcommand{\\arraystretch}{1.3}",
    "\\begin{document}\n",
    paste0("{\\Large \\textbf{", escape_latex(titulo), " Nº ", escape_latex(as.character(pregao_atual)), "}} \\\\[0.5em]\n"),
    paste0("\\textbf{Aquisição média:} ", media_str, " \\\\[0.5em]"),
    "\\noindent\\rule{\\textwidth}{0.4pt} \\\\[1em]\n",
    as.character(tabela),
    "\\end{document}"
  )
  
  # Nomes temporários na pasta raiz para compilação segura
  nome_base <- gsub("[^A-Za-z0-9_-]", "_", as.character(pregao_atual))
  prefixo_tipo <- if(grepl("sem_SEI", arquivo_pdf_final)) "sem_SEI" else "com_SEI"
  tmp_tex <- paste0("temp_", prefixo_tipo, "_", nome_base, ".tex")
  tmp_pdf <- paste0("temp_", prefixo_tipo, "_", nome_base, ".pdf")
  
  writeLines(tex_content, tmp_tex, useBytes = TRUE)
  
  sucesso <- tryCatch({
    tinytex::pdflatex(tmp_tex, engine_args = "-interaction=nonstopmode", clean = TRUE)
    TRUE
  }, error = function(e) {
    cat("\nErro LaTeX no Pregão", pregao_atual, ":", e$message, "\n")
    FALSE
  })
  
  if (sucesso && file.exists(tmp_pdf)) {
    if (file.exists(arquivo_pdf_final)) file.remove(arquivo_pdf_final)
    file.rename(tmp_pdf, arquivo_pdf_final)
    cat("PDF gerado:", basename(arquivo_pdf_final), "\n")
  }
  
  # Limpeza de resíduos
  if (file.exists(tmp_tex)) file.remove(tmp_tex)
  if (file.exists(tmp_pdf)) file.remove(tmp_pdf)
}

# ===========================================================================
# LOOP DE EXECUÇÃO
# ===========================================================================
for (pregao_atual in grupos) {
  cat("\n------------------------------------------------------------\n")
  cat("Processando Pregão:", pregao_atual, "\n")
  
  identificador <- gsub("[^A-Za-z0-9_-]", "_", as.character(pregao_atual))
  
  # 1. Proposta SEI numérica
  dados_grupo <- dados_filtrados %>%
    filter(Pregão == pregao_atual) %>%
    filter(grepl("^[0-9]+$", trimws(`Proposta (protocolo SEI)`)))
  
  if (nrow(dados_grupo) > 0) {
    pdf_saida <- file.path(pasta_saida, paste0("Relatorio_pregao_", identificador, ".pdf"))
    gerar_relatorio(dados_grupo, pregao_atual, pdf_saida, "PERCENTUAL ADQUIRIDO PELO PREGÃO")
  }
  
  # 2. Proposta SEI não numérica / sem SEI
  dados_grupo_nao_sei <- dados_filtrados %>%
    filter(Pregão == pregao_atual) %>%
    filter(!grepl("^[0-9]+$", trimws(`Proposta (protocolo SEI)`)))
  
  if (nrow(dados_grupo_nao_sei) > 0) {
    pdf_saida_nao_sei <- file.path(pasta_saida, paste0("Relatorio_pregao_", identificador, "_deserto_fracassado.pdf"))
    gerar_relatorio(dados_grupo_nao_sei, pregao_atual, pdf_saida_nao_sei, "ITENS DESERTOS/FRACASSADOS - PREGÃO")
  }
}

cat("\n==================================================================\n")
cat("PROCESSO CONCLUÍDO! Verifique a pasta '", pasta_saida, "'.\n", sep = "")
cat("==================================================================\n")