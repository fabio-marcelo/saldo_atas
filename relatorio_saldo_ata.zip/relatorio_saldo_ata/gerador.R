# ===========================================================================
# CONFIGURAÇÃO DE AMBIENTE E PACOTES (TOTALMENTE AUTOSSUFICIENTE)
# ===========================================================================
cat("Verificando e instalando pacotes necessarios. Por favor, aguarde...\n")

options(repos = c(CRAN = "https://cloud.r-project.org/"))

# --- Configuração de Ambiente para evitar erros de permissão ---
meu_diretorio_de_pacotes <- file.path(Sys.getenv("USERPROFILE"), "R_packages")
if (!dir.exists(meu_diretorio_de_pacotes)) dir.create(meu_diretorio_de_pacotes)

# Garante que o R use essa pasta para salvar os pacotes
.libPaths(c(meu_diretorio_de_pacotes, .libPaths()))

requiredPackages <- c("dplyr", "tidyr", "knitr", "readr", "stringr", 
                      "janitor", "tinytex", "kableExtra")   

# Função silenciosa para verificar e instalar pacotes
for(p in requiredPackages){
  if(!require(p, character.only = TRUE, quietly = TRUE)) {
    cat(paste("Instalando pacote:", p, "\n"))
    install.packages(p, dependencies = TRUE, repos = "https://cloud.r-project.org/")
    library(p, character.only = TRUE, quietly = TRUE)
  }
}

# ===========================================================================
# VERIFICAÇÃO INTELIGENTE DO LATEX
# ===========================================================================
tem_latex <- nzchar(Sys.which("pdflatex"))
tem_tinytex <- tinytex::is_tinytex()

if (tem_latex || tem_tinytex) {
  cat("Motor de PDF (LaTeX/MiKTeX) detectado no sistema! Pronto para gerar PDFs diretos.\n")
} else {
  cat("\n==================================================================\n")
  cat("ATENCAO: O motor de PDF nao foi encontrado neste computador.\n")
  cat("Baixando e instalando o TinyTeX. Isso pode demorar alguns minutos...\n")
  cat("==================================================================\n\n")
  
  install.packages("tinytex", repos = "https://cloud.r-project.org/")
  
  tryCatch({
    tinytex::install_tinytex(force = TRUE)
  }, error = function(e) {
    cat("\nAviso: Ocorreu um erro no servidor do TinyTeX (", e$message, ").\n")
  })
}

# Função para proteger caracteres especiais no LaTeX
escape_latex <- function(x) {
  if (is.na(x) || length(x) == 0) return("")
  x <- as.character(x)
  x <- gsub("\\\\", "\\\\textbackslash ", x)
  x <- gsub("&", "\\\\&", x)
  x <- gsub("%", "\\\\%", x)
  x <- gsub("\\$", "\\\\$", x)
  x <- gsub("#", "\\\\#", x)
  x <- gsub("_", "\\\\_", x)
  x <- gsub("\\{", "\\\\{", x)
  x <- gsub("\\}", "\\\\}", x)
  x <- gsub("~", "\\\\textasciitilde ", x)
  x <- gsub("\\^", "\\\\textasciicircum ", x)
  return(x)
}

# ===========================================================================
# PASSO 1: SELEÇÃO INTERATIVA DO ARQUIVO CSV
# ===========================================================================
cat("\n==================================================================\n")
cat("ATENCAO: A janela para escolher o arquivo CSV vai abrir agora.\n")
cat("Se nao aparecer na tela, OLHE PARA A BARRA DE TAREFAS!\n")
cat("==================================================================\n")

arquivo_entrada <- tryCatch({
  if (.Platform$OS.type == "windows") {
    res <- utils::choose.files(caption = "Selecione a planilha CSV do Empenho", multi = FALSE)
    if (length(res) == 0) stop("Cancelado")
    res
  } else {
    file.choose()
  }
}, error = function(e) {
  cat("\nSelecao de arquivo cancelada pelo usuario. Encerrando o programa.\n")
  Sys.sleep(3)
  quit(save = "no")
})

cat("\nArquivo selecionado:", arquivo_entrada, "\n\n")
cat("Iniciando processamento dos dados...\n")

# ===========================================================================
# PASSO 2: LEITURA INTELIGENTE COM DETECÇÃO AUTOMÁTICA DE CABEÇALHO
# ===========================================================================
dados_brutos_raw <- read.csv(
  arquivo_entrada,
  sep = ";",
  header = FALSE,
  stringsAsFactors = FALSE,
  encoding = "latin1",
  check.names = FALSE,
  fill = TRUE
)

detectar_cabecalho <- function(df, colunas_esperadas, minimo_match = 3){
  resultados <- sapply(seq_len(nrow(df)), function(i){
    linha <- tolower(trimws(as.character(unlist(df[i, ]))))
    sum(tolower(colunas_esperadas) %in% linha, na.rm = TRUE)
  })
  
  melhor_linha <- which.max(resultados)
  maior_match <- resultados[melhor_linha]
  
  if(maior_match < minimo_match){
    stop(
      paste0(
        "\nNão foi possível identificar automaticamente o cabeçalho.\n",
        "Maior correspondência encontrada: ", maior_match, " colunas.\n",
        "Verifique se o arquivo CSV está correto."
      )
    )
  }
  
  cat("\nCabeçalho detectado automaticamente na linha:", melhor_linha, 
      "\nColunas reconhecidas:", maior_match, "\n")
  return(melhor_linha)
}

colunas_referencia <- c(
  "Solicitante(s)",
  "Quantidade total LFDA-RS",
  "Saldo atualizado",
  "Nº Ata",
  "Item",
  "Descrição conforme Termo de Referência (anexo do edital da licitação)",
  "Porcentagem adquirida do item"
)

linha_cabecalho <- detectar_cabecalho(dados_brutos_raw, colunas_referencia)

cabecalho_real <- as.character(dados_brutos_raw[linha_cabecalho, ])
cabecalho_limpo <- cabecalho_real %>%
  gsub("[\r\n]", " ", .) %>%
  gsub("\\s+", " ", .) %>%
  trimws()

vazios <- is.na(cabecalho_limpo) | cabecalho_limpo == ""
cabecalho_limpo[vazios] <- paste0("COL_", which(vazios))

manter_colunas <- !(
  grepl("^COL_", cabecalho_limpo) &
    sapply(seq_along(cabecalho_limpo), function(i){
      all(is.na(dados_brutos_raw[-seq_len(linha_cabecalho), i]))
    })
)

dados_brutos_raw <- dados_brutos_raw[, manter_colunas]
cabecalho_limpo <- cabecalho_limpo[manter_colunas]
cabecalho_limpo <- make.unique(cabecalho_limpo)
colnames(dados_brutos_raw) <- cabecalho_limpo

dados_brutos <- dados_brutos_raw[(linha_cabecalho + 1):nrow(dados_brutos_raw), ]
dados_brutos <- dados_brutos[
  rowSums(is.na(dados_brutos) | dados_brutos == "") < ncol(dados_brutos),
]
dados_brutos <- dados_brutos[, !grepl("^NA(\\.\\d+)?$", colnames(dados_brutos))]

cat("Tabela carregada:", nrow(dados_brutos), "linhas e", ncol(dados_brutos), "colunas\n")

# ===========================================================================
# PASSO 3: PADRONIZAÇÃO DE UASG E COMBINAÇÃO ÚNICA (PREGÃO + ATA)
# ===========================================================================
dados_filtrados <- dados_brutos %>%
  mutate(
    # Normalização de strings para evitar duplicações acidentais
    Pregão = trimws(gsub("\\s+", " ", Pregão)),
    `Nº Ata` = trimws(gsub("\\s+", " ", `Nº Ata`)),
    UASG = case_when(
      str_detect(Pregão, regex("\\bRS\\b", ignore_case = TRUE)) ~ "130103",
      str_detect(Pregão, regex("\\bPA\\b", ignore_case = TRUE)) ~ "130017",
      str_detect(Pregão, regex("\\bGO\\b", ignore_case = TRUE)) ~ "130032",
      str_detect(Pregão, regex("\\bMG\\b", ignore_case = TRUE)) ~ "130058",
      str_detect(Pregão, regex("\\bPE\\b", ignore_case = TRUE)) ~ "130016",
      str_detect(Pregão, regex("\\bSP\\b", ignore_case = TRUE)) ~ "130102",
      TRUE ~ "N/A"
    )
  )

pasta_saida <- "Relatorios_PDF"
if(!dir.exists(pasta_saida)) dir.create(pasta_saida)

# Identificação ÚNICA combinando apenas Pregão e Nº Ata (itens válidos)
grupos <- dados_filtrados %>%
  filter(
    !is.na(`Nº Ata`),
    trimws(`Nº Ata`) != "",
    trimws(`Nº Ata`) != "-",
    !is.na(Pregão),
    trimws(Pregão) != ""
  ) %>%
  distinct(Pregão, `Nº Ata`)

cat("\nForam encontrados", nrow(grupos), "relatorios unicos (Pregão + Ata) para gerar.\n")
cat("------------------------------------------------------------------\n")
for (g in seq_len(nrow(grupos))) {
  cat(sprintf("[%02d] Pregão: %-25s | Ata: %s\n", g, grupos$Pregão[g], grupos$`Nº Ata`[g]))
}
cat("------------------------------------------------------------------\n")
cat("Gerando PDFs Diretamente em LaTeX, aguarde...\n\n")

# ===========================================================================
# PASSO 4: GERAÇÃO DOS RELATÓRIOS PDF EM LATEX
# ===========================================================================
for(i in seq_len(nrow(grupos))){
  
  grupo <- grupos[i, ]
  
  dados_grupo <- dados_filtrados %>%
    filter(
      Pregão == grupo$Pregão,
      `Nº Ata` == grupo$`Nº Ata`
    )
  
  uasg_atual <- unique(na.omit(dados_grupo$UASG))
  uasg_texto <- ifelse(length(uasg_atual) > 0, paste(uasg_atual, collapse = " / "), "N/A")
  
  # Sanitiza nomes para evitar erros de diretório no SO (barras '/' viram '_')
  pregao_sanitizado <- gsub("[^[:alnum:]_-]", "_", grupo$Pregão)
  ata_sanitizada    <- gsub("[^[:alnum:]_-]", "_", grupo$`Nº Ata`)
  
  identificador <- paste(pregao_sanitizado, ata_sanitizada, sep = "_")
  
  arquivo_tex <- file.path(pasta_saida, paste0("temp_", identificador, ".tex"))
  arquivo_pdf <- file.path(pasta_saida, paste0("Relatorio_", identificador, ".pdf"))
  
  cat(sprintf("[%d/%d] Gerando: Relatorio_%s.pdf\n", i, nrow(grupos), identificador))
  
  itens <- dados_grupo %>%
    select(
      Item,
      Solicitante = `Solicitante(s)`,
      `Saldo atualizado` = `Saldo atualizado`,
      `Quantidade total LFDA-RS` = `Quantidade total LFDA-RS`,
      `Nº Ata` = `Nº Ata`,
      `Descrição conforme TR` = `Descrição conforme Termo de Referência (anexo do edital da licitação)`,
      `Porcentagem adquirida do item` = `Porcentagem adquirida do item`
    ) %>%
    mutate(across(where(is.character), ~gsub("[\r\n]", " ", .)))
  
  tabela <- kable(
    itens,
    format = "latex",
    booktabs = TRUE,
    longtable = TRUE,
    escape = TRUE,
    align = c("c", "l", "r", "r", "c", "l", "c")
  ) %>%
    kable_styling(
      latex_options = c("striped", "repeat_header"),
      font_size = 7
    ) %>%
    column_spec(1, width = "1.2cm") %>%   # Item
    column_spec(2, width = "2.5cm") %>%   # Solicitante
    column_spec(3, width = "2.5cm") %>%   # Saldo atualizado
    column_spec(4, width = "2.5cm") %>%   # Quantidade
    column_spec(5, width = "1.8cm") %>%   # Nº Ata
    column_spec(6, width = "10cm") %>%    # Descrição
    column_spec(7, width = "2.5cm")       # Porcentagem
  
  tex_content <- c(
    "\\documentclass[10pt]{article}",
    "\\usepackage[landscape, left=0.7cm, right=0.7cm, top=1cm, bottom=1cm]{geometry}",
    "\\usepackage{booktabs}",
    "\\usepackage{longtable}",
    "\\usepackage{array}",
    "\\usepackage[table]{xcolor}",
    "\\usepackage[utf8]{inputenc}",
    "\\usepackage[T1]{fontenc}",
    "\\usepackage{helvet}",
    "\\renewcommand{\\familydefault}{\\sfdefault}",
    "\\setlength{\\tabcolsep}{3pt}",
    "\\renewcommand{\\arraystretch}{1.15}",
    "\\begin{document}\n",
    #"{\\Large \\textbf{PERCENTUAL ADQUIRIDO POR ITEM DA ATA}} \\\\\n",
    paste0("{\\Large \\textbf{PERCENTUAL ADQUIRIDO POR ITEM DA ATA Nº ", escape_latex(grupo$`Nº Ata`), "}} \\\\[0.5em]\n"),
    paste("\\noindent\\textbf{Pregão:} ", escape_latex(grupo$Pregão), "\\\\"),
    #paste("\\textbf{Nº da Ata:} ", escape_latex(grupo$`Nº Ata`), "\\\\"),
    paste("\\textbf{UASG:} ", escape_latex(uasg_texto), "\\\\[1em]\n"),
    "\\noindent\\rule{\\textwidth}{0.4pt} \\\\[1em]\n"
  )
  
  writeLines(c(tex_content, as.character(tabela), "\\end{document}"), arquivo_tex)
  
  tryCatch({
    tinytex::pdflatex(arquivo_tex)
    
    pdf_gerado <- sub("\\.tex$", ".pdf", arquivo_tex)
    if(file.exists(pdf_gerado)){
      if(file.exists(arquivo_pdf)) file.remove(arquivo_pdf)
      file.rename(pdf_gerado, arquivo_pdf)
    }
  }, error = function(e) {
    cat("Erro ao gerar PDF para o identificador", identificador, ":\n", e$message, "\n")
  })
  
  if(file.exists(arquivo_tex)) file.remove(arquivo_tex)
}

cat("\n==================================================================\n")
cat("PROCESSO CONCLUÍDO COM SUCESSO!\n")
cat("Todos os relatórios foram salvos na pasta '", pasta_saida, "'.\n", sep = "")
cat("==================================================================\n")