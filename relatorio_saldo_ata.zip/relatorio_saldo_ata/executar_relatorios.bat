@echo off
title Gerador de Relatorios - Percentual por Pregao
color 0A

:: Garante que o terminal roda no mesmo diretorio deste arquivo .bat
cd /d "%~dp0"

echo ========================================================
echo Gerador de Relatorios - Percentual Adquirido por Item
echo Procurando a instalacao do R no seu computador...
echo ========================================================
echo.

set "RSCRIPT_PATH="

:: 1. Verifica se Rscript esta configurado no PATH do Windows
where Rscript >nul 2>nul

if %ERRORLEVEL% EQU 0 (
    set "RSCRIPT_PATH=Rscript"
    goto :encontrado
)

:: 2. Procura pelo R na pasta padrao de 64-bits
if exist "C:\Program Files\R" (
    for /f "delims=" %%i in ('dir /b /s "C:\Program Files\R\Rscript.exe" 2^>nul') do (
        set "RSCRIPT_PATH=%%i"
        goto :encontrado
    )
)

:: 3. Procura pelo R na pasta padrao de 32-bits
if exist "C:\Program Files (x86)\R" (
    for /f "delims=" %%i in ('dir /b /s "C:\Program Files (x86)\R\Rscript.exe" 2^>nul') do (
        set "RSCRIPT_PATH=%%i"
        goto :encontrado
    )
)

:: Se nao encontrou em nenhum dos locais
goto :nao_encontrado

:encontrado

echo R encontrado com sucesso!
echo Executavel: "%RSCRIPT_PATH%"
echo.

echo ========================================================
echo ATENCAO: A janela para selecionar o CSV vai abrir.
echo (Se nao aparecer, verifique a Barra de Tarefas do Windows)
echo ========================================================
echo.

"%RSCRIPT_PATH%" gerador.R

:: Verifica o codigo de retorno do R
if %ERRORLEVEL% EQU 0 (
    echo.
    echo Script finalizado com sucesso!
    echo Abrindo pasta de relatorios...

    if exist "Relatorios_PDF" (
        explorer "Relatorios_PDF"
    )
) else (
    color 0C
    echo.
    echo ========================================================
    echo O SCRIPT R ENCONTROU UM ERRO E FOI INTERROMPIDO.
    echo Verifique os avisos acima para identificar o problema.
    echo ========================================================
)

goto :fim

:nao_encontrado

color 0C

echo ========================================================
echo ERRO: O executavel do R (Rscript.exe) nao foi localizado.
echo ========================================================
echo.

echo Por favor, instale o R no computador atraves do link oficial:
echo https://cran.r-project.org/bin/windows/base/
echo.

:fim

echo.
echo Pressione qualquer tecla para fechar esta janela...
pause >nul